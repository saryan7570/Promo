package com.cg.promo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.promo.entity.Promo;

public interface PromoDao extends JpaRepository<Promo, Integer> {

}

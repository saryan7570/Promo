package com.cg.promo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.promo.dao.PromoDao;
import com.cg.promo.entity.Promo;

@Service
public class PromoServiceImpl implements PromoService {

	@Autowired
	PromoDao promosDao;

	@Override
	public List<Promo> add(Promo promos) {
		promosDao.save(promos);
		return promosDao.findAll();
	}

}

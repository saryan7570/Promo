package com.cg.promo.service;

import java.util.List;

import com.cg.promo.entity.Promo;

public interface PromoService {
	
	public List<Promo> add(Promo promos);

}
